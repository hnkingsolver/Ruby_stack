class Ninja < ActiveRecord::Base
  belongs_to :dojo
end
