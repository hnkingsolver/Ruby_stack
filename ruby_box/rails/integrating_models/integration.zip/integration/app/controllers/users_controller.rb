class UsersController < ApplicationController
  def index
    # render json:@users
    @users=User.all
  end

  def new
  end
  @@num_of_users = 0
  def create
    # @user = User.create(name: params[:user]['name'])
    @user = User.create(user_params) #new better way so we dont have really long code
    @@num_of_users += 1
    redirect_to '/users'
  end

  def show
    @user = User.find(params[:id])
    render json:@user
  end

  def edit
    @user = User.find(params[:id])
  end

  def update
    if @user.update(user_params)
      redirect_to '/users'
    end
  end

  def total
    @users=User.all
    @count=@users.count
  end

  def destroy
  end

  private #made this function private so it cannot be accessed anywhere but here.. can use it when we need to call params
  def user_params
    params.require(:user).permit(:name)
  end
end
