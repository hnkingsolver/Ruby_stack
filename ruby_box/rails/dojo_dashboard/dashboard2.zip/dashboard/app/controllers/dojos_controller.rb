class DojosController < ApplicationController
    def index
        @dojos = Dojo.all
    end
    def new
    end
    def create
        @dojo = Dojo.create(dojo_params)
        puts @dojo.errors.full_messages
        redirect_to '/dojos'
    end




    private #made this function private so it cannot be accessed anywhere but here.. can use it when we need to call params
    def dojo_params
        params.require(:dojo).permit(:branch, :street, :city, :state)
    end
end
