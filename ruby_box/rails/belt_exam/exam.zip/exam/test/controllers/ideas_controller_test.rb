require 'test_helper'

class IdeasControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
